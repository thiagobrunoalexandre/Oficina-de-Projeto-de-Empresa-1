﻿using Microsoft.AspNetCore.Http;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Alge
{
    public static class AlgeCookieController
    {
        const String KEY_USUARIO_ADMIN_ID = "UsuarioAdminID";
        const String KEY_USUARIO_ADMIN_EMAIL = "UsuarioAdminEmail";
        const String KEY_CORRETORA_ADMIN_ID = "CorretoraAdminID";

        public static String CorretoraID
        {
            set
            {
                AppHttpContext.Current.Session.SetString(KEY_CORRETORA_ADMIN_ID, value);
            }
            get
            {
                return AppHttpContext.Current.Session.GetString(KEY_CORRETORA_ADMIN_ID);
            }
        }

        public static String UsuarioAdminID
        {
            set
            {
                AppHttpContext.Current.Session.SetString(KEY_USUARIO_ADMIN_ID, value);
            }
            get
            {
                return AppHttpContext.Current.Session.GetString(KEY_USUARIO_ADMIN_ID);
            }
        }

        public static String UsuarioAdminEmail
        {
            set
            {
                AppHttpContext.Current.Session.SetString(KEY_USUARIO_ADMIN_EMAIL, value);
            }
            get
            {
                return AppHttpContext.Current.Session.GetString(KEY_USUARIO_ADMIN_EMAIL);
            }
        }

        public static void ClearSession()
        {
            AppHttpContext.Current.Session.Clear();
        }
    }
}
